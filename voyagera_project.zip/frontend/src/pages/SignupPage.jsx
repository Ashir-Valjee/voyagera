import SignupForm from "../components/SignUp"

const SignupLogin = () => {
    return (
        <>
            <div>
                <h1>Welcome!</h1>
                <SignupForm />
            </div>
        </>
    )
}

export default SignupLogin;