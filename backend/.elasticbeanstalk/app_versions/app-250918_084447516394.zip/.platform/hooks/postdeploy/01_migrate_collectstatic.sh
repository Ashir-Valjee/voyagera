#!/bin/bash
set -e
# Activate EB's virtualenv and run your Django maintenance tasks
source /var/app/venv/*/bin/activate
python manage.py migrate --noinput
python manage.py collectstatic --noinput
