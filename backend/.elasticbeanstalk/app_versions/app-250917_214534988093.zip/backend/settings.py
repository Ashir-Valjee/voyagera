"""
Django settings for backend project.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# -----------------------------------------------------------------------------
# Paths & env
# -----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv()  # load .env for local dev; EB uses environment vars

# -----------------------------------------------------------------------------
# Core security
# -----------------------------------------------------------------------------
SECRET_KEY = os.getenv("DJANGO_SECRET_KEY", "dev-insecure-key-change-me")
DEBUG = os.getenv("DEBUG", "false").lower() == "true"

# Comma-separated hosts in env, plus sensible dev defaults
ALLOWED_HOSTS = [
    h.strip()
    for h in (os.getenv("ALLOWED_HOSTS") or "").split(",")
    if h.strip()
] or (["localhost", "127.0.0.1"] if DEBUG else [])

# If you want to be explicit for EB hostname:
APP_HOST = os.getenv("APP_HOST", "").strip()
if APP_HOST:
    ALLOWED_HOSTS.append(APP_HOST)

# -----------------------------------------------------------------------------
# Graphene / GraphQL
# -----------------------------------------------------------------------------
GRAPHENE = {
    "SCHEMA": "api.schema.schema",
}

# -----------------------------------------------------------------------------
# JWT config (from your existing code)
# -----------------------------------------------------------------------------
JWT_ACCESS_SECRET = os.getenv("JWT_ACCESS_SECRET", SECRET_KEY)
JWT_REFRESH_SECRET = os.getenv("JWT_REFRESH_SECRET", SECRET_KEY)
JWT_ALG = os.getenv("JWT_ALG", "HS256")
JWT_ACCESS_MINUTES = int(os.getenv("JWT_ACCESS_MINUTES", "30"))
JWT_REFRESH_DAYS = int(os.getenv("JWT_REFRESH_DAYS", "7"))

# -----------------------------------------------------------------------------
# Installed apps
# -----------------------------------------------------------------------------
INSTALLED_APPS = [
    # Django
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # 3rd party
    "graphene_django",
    "corsheaders",
    "storages",          # for S3 media
    "whitenoise.runserver_nostatic",  # nicer local static serving
    # Local
    "api.apps.ApiConfig",
]

# -----------------------------------------------------------------------------
# Middleware
# -----------------------------------------------------------------------------
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",  # static files (prod & dev)
    "corsheaders.middleware.CorsMiddleware",       # CORS before CommonMiddleware
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "backend.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "backend.wsgi.application"

# -----------------------------------------------------------------------------
# Database
# - In prod, set DATABASE_URL (e.g. postgres://user:pass@host:5432/dbname)
# - In dev, falls back to local Postgres if DB_* present, else SQLite
# -----------------------------------------------------------------------------
def _default_db():
    # Prefer local Postgres if DB_USERNAME present
    if os.getenv("DB_USERNAME"):
        return {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.getenv("DB_NAME", "voyagera"),
            "USER": os.getenv("DB_USERNAME"),
            "PASSWORD": os.getenv("DB_PASSWORD", ""),
            "HOST": os.getenv("DB_HOST", "localhost"),
            "PORT": os.getenv("DB_PORT", "5432"),
        }
    # Fallback to SQLite for quick local dev
    return {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }

DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
if DATABASE_URL:
    # Use dj-database-url if available; else minimal parse
    try:
        import dj_database_url  # type: ignore
        DATABASES = {
            "default": dj_database_url.config(
                default=DATABASE_URL, conn_max_age=600, ssl_require=True
            )
        }
    except Exception:
        # Minimal fallback (no pooling)
        DATABASES = {"default": _default_db()}
else:
    DATABASES = {"default": _default_db()}

# -----------------------------------------------------------------------------
# Password validation
# -----------------------------------------------------------------------------
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# -----------------------------------------------------------------------------
# I18N / TZ
# -----------------------------------------------------------------------------
LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

# -----------------------------------------------------------------------------
# Static files (served by WhiteNoise from /staticfiles)
# -----------------------------------------------------------------------------
STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

# Use WhiteNoise hashed storage for optimal caching
STORAGES = {
    # Default file storage (media). We’ll pick S3 if a bucket is configured; else local.
    "default": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
    },
    # Versioned & compressed static files
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage",
    },
}

# -----------------------------------------------------------------------------
# Media files: S3 if configured, else local MEDIA/
# -----------------------------------------------------------------------------
AWS_STORAGE_BUCKET_NAME = os.getenv("AWS_STORAGE_BUCKET_NAME", "voyagera-images-2025")
AWS_S3_REGION_NAME = os.getenv("AWS_S3_REGION_NAME", "eu-west-2")
AWS_S3_CUSTOM_DOMAIN = f"{AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com"
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")

USE_S3_MEDIA = bool(AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY and AWS_STORAGE_BUCKET_NAME)

if USE_S3_MEDIA:
    # Switch default storage to S3 only if creds & bucket are present
    STORAGES["default"] = {"BACKEND": "storages.backends.s3boto3.S3Boto3Storage"}

    AWS_S3_SIGNATURE_VERSION = os.getenv("AWS_S3_SIGNATURE_VERSION", "s3v4")
    AWS_S3_ADDRESSING_STYLE = os.getenv("AWS_S3_ADDRESSING_STYLE", "virtual")
    AWS_S3_FILE_OVERWRITE = False
    AWS_DEFAULT_ACL = None

    MEDIA_URL = f"https://{AWS_S3_CUSTOM_DOMAIN}/"
    MEDIA_ROOT = ""  # not used with S3
else:
    MEDIA_URL = "/media/"
    MEDIA_ROOT = BASE_DIR / "media"

# -----------------------------------------------------------------------------
# CORS / CSRF (frontend on CloudFront or custom domain)
# -----------------------------------------------------------------------------
FRONTEND_HOST = os.getenv("FRONTEND_HOST", "").strip()  # e.g. dxxxxxxxx.cloudfront.net or app.example.com

CORS_ALLOWED_ORIGINS = []
CSRF_TRUSTED_ORIGINS = []

if FRONTEND_HOST:
    CORS_ALLOWED_ORIGINS.append(f"https://{FRONTEND_HOST}")
    CSRF_TRUSTED_ORIGINS.append(f"https://{FRONTEND_HOST}")

# Useful dev origins
if DEBUG:
    CORS_ALLOWED_ORIGINS += [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]
    CSRF_TRUSTED_ORIGINS += [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]

# -----------------------------------------------------------------------------
# Security headers for reverse proxy / HTTPS (EB)
# -----------------------------------------------------------------------------
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SECURE_SSL_REDIRECT = os.getenv("SECURE_SSL_REDIRECT", "true").lower() == "true" and not DEBUG

SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG

# HSTS (enable after confirming HTTPS works)
SECURE_HSTS_SECONDS = int(os.getenv("SECURE_HSTS_SECONDS", "0" if DEBUG else "31536000"))
SECURE_HSTS_INCLUDE_SUBDOMAINS = os.getenv("SECURE_HSTS_INCLUDE_SUBDOMAINS", "false").lower() == "true"
SECURE_HSTS_PRELOAD = os.getenv("SECURE_HSTS_PRELOAD", "false").lower() == "true"

# -----------------------------------------------------------------------------
# Default PK
# -----------------------------------------------------------------------------
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
